﻿using HorizonApp.DataStore;
using HorizonApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace HorizonApp.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ProductController : ApiController
    {
        HorizonEntities context = new HorizonEntities();
        // GET api/Product
        public IEnumerable<Models.Products> Get()
        {
            return context.Products.Select(x => new Models.Products { id = x.id, prod_desc = x.prod_desc, prod_name = x.prod_name, prod_price = x.prod_price, update_at = x.update_at }).ToList();
        }

        // GET api/Product/5
        public Models.Products Get(int id)
        {
            return context.Products.Where(x=>x.id == id).Select(x => new Models.Products { id = x.id, prod_desc = x.prod_desc, prod_name = x.prod_name, prod_price = x.prod_price, update_at = x.update_at }).FirstOrDefault();
        }

        // POST api/Product
        public Models.Products Post([FromBody]Models.Products product)
        {
            DataStore.Product prod = new DataStore.Product();
            //prod.id = product.id;
            prod.prod_name = product.prod_name;
            prod.prod_desc = product.prod_desc;
            prod.prod_price = product.prod_price;
            prod.update_at = DateTime.Now;

            context.Products.Add(prod);
            context.SaveChanges();

            return Get(prod.id);

        }

        // PUT api/Product/5
        public Models.Products Put(int id, [FromBody]Models.Products product)
        {

            DataStore.Product prod = context.Products.SingleOrDefault(x => x.id == id);
            if (prod != null)
            {
                //set model id
                product.id = prod.id;

                prod.prod_name = product.prod_name;
                prod.prod_desc = product.prod_desc;
                prod.prod_price = product.prod_price;
                prod.update_at = DateTime.Now;

                context.SaveChanges();
            }

            return product;
        }

        // DELETE api/Product/5
        public void Delete(int id)
        {
            DataStore.Product prod = context.Products.SingleOrDefault(x => x.id == id);
            if (prod != null)
            {
                context.Products.Remove(prod);
                context.SaveChanges();
            }
        }
    }
}

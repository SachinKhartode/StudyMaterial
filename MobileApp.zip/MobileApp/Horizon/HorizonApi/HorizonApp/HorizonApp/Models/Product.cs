﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HorizonApp.Models
{
    public class Products
    {
        public int id { get; set; }
        public string prod_name { get; set; }
        public string prod_desc { get; set; }
        public Nullable<decimal> prod_price { get; set; }
        public Nullable<System.DateTime> update_at { get; set; }
    }
}
import { NgModule,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouteReuseStrategy, RouterModule } from '@angular/router';
import {
  MatInputModule,
  MatPaginatorModule,
  MatProgressSpinnerModule,
  MatSortModule,
  MatTableModule,
  MatIconModule,
  MatButtonModule,
  MatCardModule,
  MatFormFieldModule } from "@angular/material";
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

//import { MenuPageModule } from '../app/menu/menu.module';
import { LoginPageModule } from '../app/login/login.module';
// import { HomePagePageModule } from '../app/product/home-page/home-page.module';
// import { AddPagePageModule } from '../app/product/add-page/add-page.module';
// import { EditPagePageModule } from '../app/product/edit-page/edit-page.module';
// import { TabsPagePageModule } from '../app/product/tabs-page/tabs-page.module';
// import { DetailsPagePageModule } from '../app/product/details-page/details-page.module';

//import { HomePagePage } from '../app/product/home-page/home-page.page';
import { MenuPage } from '../app/menu/menu.page';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, 
    IonicModule.forRoot(), 
    AppRoutingModule,
    BrowserAnimationsModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    DragDropModule,
    ScrollingModule,
    RouterModule.forChild([{ path: '', component: LoginPageModule }]),
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule,
    // HomePagePageModule,
    // TabsPagePageModule,
    // AddPagePageModule,
    // EditPagePageModule,
    // DetailsPagePageModule,
    LoginPageModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}

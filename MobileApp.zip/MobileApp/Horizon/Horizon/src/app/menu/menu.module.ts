import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { MenuPage } from './menu.page';
//import { TabsPagePage } from '../../product/tabs-page/tabs-page.page';

const routes: Routes = [
  {
    path: '',
    component: MenuPage,
    children: [
      {
        path: 'tabs',
        loadChildren: '../product/tabs-page/tabs-page.module#TabsPagePageModule'
      }
       
    ]
  }

  // {
  //   path: '',
  //   redirectTo: '../product/home-page/home/',
  //   pathMatch: 'full'
  // }
  //{ path: 'menu', loadChildren: './menu/menu/menu.module#MenuPageModule' }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [MenuPage]
})
export class MenuPageModule {}

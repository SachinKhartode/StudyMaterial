import { Injectable } from '@angular/core';
import { Observable, of, throwError, observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { Product } from './product';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
const apiUrl = "http://localhost:65093/api/Product";

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  constructor(private http: HttpClient) { }
  products : Product[] = [];
  getProducts(): Observable<Product[]> {
    const url = `${apiUrl}`;
    return this.http.get<Product[]>(url).pipe(
      tap(_ => console.log(`fetched all product`)),
      catchError(this.handleError<Product[]>(`getProducts`))
    );
  //   this.products = [new Product(1, "Laptop", "adsfas", 100, new Date()),
  //   new Product(2, "Desktop", "adfa", 100, new Date()),
  //   new Product(3, "Mouse", "adfa", 10, new Date()),
  //   new Product(4, "Keybord", "asdfasd", 10, new Date())
  // ];

    //return new Observable(obs => obs.next(this.products));
    return Observable.create(observer => {observer.next(this.products);});
  }

  getProduct(id): Observable<Product> {
    const url = `${apiUrl}/${id}`;
    return this.http.get<Product>(url).pipe(
      tap(_ => console.log(`fetched product id=${id}`)),
      catchError(this.handleError<Product>(`getProduct id=${id}`))
    );
  }
  
  addProduct (product): Observable<Product> {
    return this.http.post<Product>(apiUrl, product, httpOptions).pipe(
      tap((product: Product) => console.log(`added product w/ id=${product.id}`)),
      catchError(this.handleError<Product>('addProduct'))
    );
  }
  
  updateProduct (id, product): Observable<any> {
    const url = `${apiUrl}/${id}`;
    return this.http.put(url, product, httpOptions).pipe(
      tap(_ => console.log(`updated product id=${id}`)),
      catchError(this.handleError<any>('updateProduct'))
    );
  }
  
  deleteProduct (id): Observable<Product> {
    const url = `${apiUrl}/${id}`;
  
    return this.http.delete<Product>(url, httpOptions).pipe(
      tap(_ => console.log(`deleted product id=${id}`)),
      catchError(this.handleError<Product>('deleteProduct'))
    );
  }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
  
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
  
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}

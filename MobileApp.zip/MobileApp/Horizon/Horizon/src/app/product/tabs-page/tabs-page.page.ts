import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs-page',
  templateUrl: './tabs-page.page.html',
  styleUrls: ['./tabs-page.page.scss'],
})
export class TabsPagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { TabsPagePage } from './tabs-page.page';

const routes: Routes = [
  {
    path: 'productTabs',
    component: TabsPagePage,
    children: [
      {
        path: 'home',
        loadChildren: '../home-page/home-page.module#HomePagePageModule'
      },
      {
        path: 'add',
        loadChildren: '../add-page/add-page.module#AddPagePageModule'
      },
      {
        path: 'edit',
        loadChildren: '../edit-page/edit-page.module#EditPagePageModule'
      },
      {
        path: 'edit/:id',
        loadChildren: '../edit-page/edit-page.module#EditPagePageModule'
      },
      {
        path: 'details',
        loadChildren: '../details-page/details-page.module#DetailsPagePageModule'
      },
      {
        path: 'details/:id',
        loadChildren: '../details-page/details-page.module#DetailsPagePageModule'
      }
  ]},
  {
    path: '',
    //redirectTo: '../product/home-page/home/',
    redirectTo : 'productTabs/home',
    pathMatch: 'full'
  }
  //{ path: 'menu', loadChildren: './menu/menu/menu.module#MenuPageModule' }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [TabsPagePage]
})
export class TabsPagePageModule {}

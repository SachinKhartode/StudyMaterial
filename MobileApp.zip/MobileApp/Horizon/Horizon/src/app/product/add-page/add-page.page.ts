import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController } from '@ionic/angular';
import { ProductServiceService } from '../product-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Product } from '../product';

@Component({
  selector: 'app-add-page',
  templateUrl: './add-page.page.html',
  styleUrls: ['./add-page.page.scss'],
})
export class AddPagePage implements OnInit {

  productForm: FormGroup;
  prod_name:string='';
  prod_desc:string='';
  prod_price:number=null;

  constructor(public api: ProductServiceService,
    public loadingController: LoadingController,
    public alertController: AlertController,
    public route: ActivatedRoute,
    public router: Router,
    private formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.productForm = this.formBuilder.group({
      prod_name : ['', Validators.required],
      prod_desc : ['', Validators.required],
      prod_price : ['', Validators.required]
    });
  }

  async onFormSubmit(form:NgForm) {
    const loading = await this.loadingController.create({
      message: 'Loading...'
    });
    await loading.present();
    await this.api.addProduct(form)
      .subscribe(res => {
          let id = res['id'];
          loading.dismiss();
          console.log(this.router);

          //this.router.navigate([ { outlets: { details: id } } ], { relativeTo: this.route.parent });
          this.router.navigate([ `/tabs/details/${id}`]);
        }, (err) => {
          console.log(err);
          loading.dismiss();
        });
  }


}

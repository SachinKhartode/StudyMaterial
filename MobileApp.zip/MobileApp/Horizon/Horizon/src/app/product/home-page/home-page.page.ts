import { Component, OnInit } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductServiceService } from '../product-service.service';
import { Product } from '../product';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.page.html',
  styleUrls: ['./home-page.page.scss'],
})
export class HomePagePage implements OnInit {

  products: Product[] = [];

  constructor(public api: ProductServiceService,
    public loadingController: LoadingController,
    public router: Router,
    public route: ActivatedRoute) { }

  ngOnInit() {
    this.getProducts();
  }

  async getProducts() {
    const loading = await this.loadingController.create({
      message: 'Loading...'
    });
    await loading.present();
    await this.api.getProducts()
      .subscribe((res) => {
        this.products = res;
        console.log(this.products);
        loading.dismiss();
      }, err => {
        console.log(err);
        loading.dismiss();
      });

      // .subscribe(res => {
      //   this.products = res;
      //   console.log(this.products);
      //   loading.dismiss();
      // }, err => {
      //   console.log(err);
      //   loading.dismiss();
      // });

      // .subscribe((x)=>{ 
      //       this.products = x
      //       console.log(x);
      //       loading.dismiss();
      //  });
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.products, event.previousIndex, event.currentIndex);
  }

}

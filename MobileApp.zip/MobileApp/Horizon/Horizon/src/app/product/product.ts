export class Product {
    id: number;
    prod_name: string;
    prod_desc: string;
    prod_price: number;
    updated_at: Date;

    constructor(id1: number,name: string,desc: string,price: number,updated: Date){
      this.id = id1;
      this.prod_name= name;
      this.prod_desc = desc;
      this.prod_price = price;
      this.updated_at = updated;
    }
  }
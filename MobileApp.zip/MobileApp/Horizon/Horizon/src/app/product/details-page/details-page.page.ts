import { Component, OnInit } from '@angular/core';
import { LoadingController, AlertController } from '@ionic/angular';
import { ProductServiceService } from '../../product/product-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-details-page',
  templateUrl: './details-page.page.html',
  styleUrls: ['./details-page.page.scss'],
})
export class DetailsPagePage implements OnInit {

  product:Product = { id: null, prod_name: '', prod_desc: '', prod_price: null, updated_at: null };

  constructor(public api: ProductServiceService,
    public loadingController: LoadingController,
    public alertController: AlertController,
    public route: ActivatedRoute,
    public router: Router) {}

  ngOnInit() {
    this.getProduct();
  }

  async getProduct() {
    if(this.route.snapshot.paramMap.get('id') == null) {
      this.presentAlertConfirm('You are not choosing an item from the list');
    } else {
      const loading = await this.loadingController.create({
        message: 'Loading...'
      });
      await loading.present();
      await this.api.getProduct(this.route.snapshot.paramMap.get('id'))
        .subscribe(res => {
          console.log(res);
          this.product = res;
          loading.dismiss();
        }, err => {
          console.log(err);
          loading.dismiss();
        });
    }
  }

  async presentAlertConfirm(msg: string) {
    const alert = await this.alertController.create({
      header: 'Warning!',
      message: msg,
      buttons: [
        {
          text: 'Okay',
          handler: () => {
            this.router.navigate(['']);
          }
        }
      ]
    });
  
    await alert.present();
  }


  async delete(id) {

    if(id == null) {
      this.presentAlertConfirm('You are not choosing an item from the list');
    } 
    else{
      const loading = await this.loadingController.create({
        message: 'Loading...'
      });
      await loading.present();
      await this.api.deleteProduct(id)
        .subscribe(res => {
          loading.dismiss();
          //this.router.navigate([ '/tabs', { outlets: { home: 'home' } } ]);
          this.router.navigate([ 'tabs/productTabs/home']);
        }, err => {
          console.log(err);
          loading.dismiss();
        });
    }
  }

}

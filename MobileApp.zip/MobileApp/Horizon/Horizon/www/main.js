(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/legacy lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/legacy lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-controller_7.entry.js",
		13
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-ios.entry.js",
		"common",
		14
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-action-sheet-md.entry.js",
		"common",
		15
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-alert-ios.entry.js",
		"common",
		16
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-alert-md.entry.js",
		"common",
		17
	],
	"./ion-anchor_6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-anchor_6.entry.js",
		1,
		"common",
		18
	],
	"./ion-app_7-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-app_7-ios.entry.js",
		"common",
		19
	],
	"./ion-app_7-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-app_7-md.entry.js",
		"common",
		20
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-avatar_3-ios.entry.js",
		"common",
		21
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-avatar_3-md.entry.js",
		"common",
		22
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-back-button-ios.entry.js",
		"common",
		23
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-back-button-md.entry.js",
		"common",
		24
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-backdrop-ios.entry.js",
		0,
		"common",
		25
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-backdrop-md.entry.js",
		0,
		"common",
		26
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-button_2-ios.entry.js",
		"common",
		27
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-button_2-md.entry.js",
		"common",
		28
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-card_5-ios.entry.js",
		"common",
		29
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-card_5-md.entry.js",
		"common",
		30
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-checkbox-ios.entry.js",
		"common",
		31
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-checkbox-md.entry.js",
		"common",
		32
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-chip-ios.entry.js",
		"common",
		33
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-chip-md.entry.js",
		"common",
		34
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-col_3.entry.js",
		35
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-datetime_3-ios.entry.js",
		"common",
		36
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-datetime_3-md.entry.js",
		"common",
		37
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-fab_3-ios.entry.js",
		"common",
		38
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-fab_3-md.entry.js",
		"common",
		39
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-img.entry.js",
		40
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-infinite-scroll_2-ios.entry.js",
		"common",
		41
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-infinite-scroll_2-md.entry.js",
		"common",
		42
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-input-ios.entry.js",
		"common",
		43
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-input-md.entry.js",
		"common",
		44
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item-option_3-ios.entry.js",
		"common",
		45
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item-option_3-md.entry.js",
		"common",
		46
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item_8-ios.entry.js",
		"common",
		47
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-item_8-md.entry.js",
		"common",
		48
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-loading-ios.entry.js",
		"common",
		49
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-loading-md.entry.js",
		"common",
		50
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-menu_4-ios.entry.js",
		0,
		"common",
		51
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-menu_4-md.entry.js",
		0,
		"common",
		52
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-modal-ios.entry.js",
		1,
		"common",
		53
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-modal-md.entry.js",
		1,
		"common",
		54
	],
	"./ion-nav_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-nav_4.entry.js",
		1,
		"common",
		55
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-popover-ios.entry.js",
		1,
		"common",
		56
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-popover-md.entry.js",
		1,
		"common",
		57
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-progress-bar-ios.entry.js",
		"common",
		58
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-progress-bar-md.entry.js",
		"common",
		59
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-radio_2-ios.entry.js",
		"common",
		60
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-radio_2-md.entry.js",
		"common",
		61
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-range-ios.entry.js",
		"common",
		62
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-range-md.entry.js",
		"common",
		63
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-refresher_2-ios.entry.js",
		"common",
		64
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-refresher_2-md.entry.js",
		"common",
		65
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-reorder_2-ios.entry.js",
		"common",
		66
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-reorder_2-md.entry.js",
		"common",
		67
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-ripple-effect.entry.js",
		68
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-searchbar-ios.entry.js",
		"common",
		69
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-searchbar-md.entry.js",
		"common",
		70
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-segment_2-ios.entry.js",
		"common",
		71
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-segment_2-md.entry.js",
		"common",
		72
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-select_3-ios.entry.js",
		"common",
		73
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-select_3-md.entry.js",
		"common",
		74
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-slide_2-ios.entry.js",
		"common",
		75
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-slide_2-md.entry.js",
		"common",
		76
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-spinner.entry.js",
		"common",
		77
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-split-pane-ios.entry.js",
		78
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-split-pane-md.entry.js",
		79
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab-bar_2-ios.entry.js",
		"common",
		80
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab-bar_2-md.entry.js",
		"common",
		81
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-tab_2.entry.js",
		"common",
		10
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-text.entry.js",
		"common",
		82
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-textarea-ios.entry.js",
		"common",
		83
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-textarea-md.entry.js",
		"common",
		84
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toast-ios.entry.js",
		"common",
		85
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toast-md.entry.js",
		"common",
		86
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toggle-ios.entry.js",
		"common",
		87
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-toggle-md.entry.js",
		"common",
		88
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/legacy/ion-virtual-scroll.entry.js",
		89
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/legacy lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _app_product_home_page_home_page_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app/product/home-page/home-page.page */ "./src/app/product/home-page/home-page.page.ts");
/* harmony import */ var _app_product_tabs_page_tabs_page_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../app/product/tabs-page/tabs-page.page */ "./src/app/product/tabs-page/tabs-page.page.ts");
/* harmony import */ var _app_product_add_page_add_page_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../app/product/add-page/add-page.page */ "./src/app/product/add-page/add-page.page.ts");
/* harmony import */ var _app_product_edit_page_edit_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../app/product/edit-page/edit-page.page */ "./src/app/product/edit-page/edit-page.page.ts");
/* harmony import */ var _app_product_details_page_details_page_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../app/product/details-page/details-page.page */ "./src/app/product/details-page/details-page.page.ts");








// const routes: Routes = [
//   { path: '', redirectTo: 'home', pathMatch: 'full' },
//   { path: 'home', loadChildren: './home/home.module#HomePageModule' },
// ];
var routes = [
    {
        path: 'tabs',
        component: _app_product_tabs_page_tabs_page_page__WEBPACK_IMPORTED_MODULE_4__["TabsPagePage"],
        children: [
            {
                path: '',
                redirectTo: '/tabs/(home:home)',
                pathMatch: 'full',
            },
            {
                path: 'home',
                outlet: 'home',
                component: _app_product_home_page_home_page_page__WEBPACK_IMPORTED_MODULE_3__["HomePagePage"]
            },
            {
                path: 'add',
                outlet: 'add',
                component: _app_product_add_page_add_page_page__WEBPACK_IMPORTED_MODULE_5__["AddPagePage"]
            },
            {
                path: ':id',
                outlet: 'edit',
                component: _app_product_edit_page_edit_page_page__WEBPACK_IMPORTED_MODULE_6__["EditPagePage"]
            },
            {
                path: ':id',
                outlet: 'details',
                component: _app_product_details_page_details_page_page__WEBPACK_IMPORTED_MODULE_7__["DetailsPagePage"]
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/(home:home)',
        pathMatch: 'full'
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-home-page></app-home-page>\n\n<ion-app>\n  \n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");





var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
        });
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "./node_modules/@angular/cdk/esm5/drag-drop.es5.js");
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/scrolling */ "./node_modules/@angular/cdk/esm5/scrolling.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_product_home_page_home_page_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../app/product/home-page/home-page.module */ "./src/app/product/home-page/home-page.module.ts");
/* harmony import */ var _app_product_add_page_add_page_module__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../app/product/add-page/add-page.module */ "./src/app/product/add-page/add-page.module.ts");
/* harmony import */ var _app_product_edit_page_edit_page_module__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../app/product/edit-page/edit-page.module */ "./src/app/product/edit-page/edit-page.module.ts");
/* harmony import */ var _app_product_tabs_page_tabs_page_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../app/product/tabs-page/tabs-page.module */ "./src/app/product/tabs-page/tabs-page.module.ts");
/* harmony import */ var _app_product_details_page_details_page_module__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../app/product/details-page/details-page.module */ "./src/app/product/details-page/details-page.module.ts");
/* harmony import */ var _app_product_home_page_home_page_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../app/product/home-page/home-page.page */ "./src/app/product/home-page/home-page.page.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");






















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_13__["AppComponent"]],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_14__["AppRoutingModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_21__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"],
                _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_6__["DragDropModule"],
                _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_7__["ScrollingModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{ path: '', component: _app_product_home_page_home_page_page__WEBPACK_IMPORTED_MODULE_20__["HomePagePage"] }]),
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatPaginatorModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatProgressSpinnerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSortModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatTableModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatFormFieldModule"],
                _app_product_home_page_home_page_module__WEBPACK_IMPORTED_MODULE_15__["HomePagePageModule"],
                _app_product_tabs_page_tabs_page_module__WEBPACK_IMPORTED_MODULE_18__["TabsPagePageModule"],
                _app_product_add_page_add_page_module__WEBPACK_IMPORTED_MODULE_16__["AddPagePageModule"],
                _app_product_edit_page_edit_page_module__WEBPACK_IMPORTED_MODULE_17__["EditPagePageModule"],
                _app_product_details_page_details_page_module__WEBPACK_IMPORTED_MODULE_19__["DetailsPagePageModule"]
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_12__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_11__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_13__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/product/add-page/add-page.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/product/add-page/add-page.module.ts ***!
  \*****************************************************/
/*! exports provided: AddPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddPagePageModule", function() { return AddPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _add_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./add-page.page */ "./src/app/product/add-page/add-page.page.ts");







var routes = [
    {
        path: '',
        component: _add_page_page__WEBPACK_IMPORTED_MODULE_6__["AddPagePage"]
    }
];
var AddPagePageModule = /** @class */ (function () {
    function AddPagePageModule() {
    }
    AddPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_add_page_page__WEBPACK_IMPORTED_MODULE_6__["AddPagePage"]]
        })
    ], AddPagePageModule);
    return AddPagePageModule;
}());



/***/ }),

/***/ "./src/app/product/add-page/add-page.page.html":
/*!*****************************************************!*\
  !*** ./src/app/product/add-page/add-page.page.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>addPage</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/product/add-page/add-page.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/product/add-page/add-page.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QvYWRkLXBhZ2UvYWRkLXBhZ2UucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/product/add-page/add-page.page.ts":
/*!***************************************************!*\
  !*** ./src/app/product/add-page/add-page.page.ts ***!
  \***************************************************/
/*! exports provided: AddPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddPagePage", function() { return AddPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AddPagePage = /** @class */ (function () {
    function AddPagePage() {
    }
    AddPagePage.prototype.ngOnInit = function () {
    };
    AddPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-add-page',
            template: __webpack_require__(/*! ./add-page.page.html */ "./src/app/product/add-page/add-page.page.html"),
            styles: [__webpack_require__(/*! ./add-page.page.scss */ "./src/app/product/add-page/add-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], AddPagePage);
    return AddPagePage;
}());



/***/ }),

/***/ "./src/app/product/details-page/details-page.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/product/details-page/details-page.module.ts ***!
  \*************************************************************/
/*! exports provided: DetailsPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPagePageModule", function() { return DetailsPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _details_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./details-page.page */ "./src/app/product/details-page/details-page.page.ts");







var routes = [
    {
        path: '',
        component: _details_page_page__WEBPACK_IMPORTED_MODULE_6__["DetailsPagePage"]
    }
];
var DetailsPagePageModule = /** @class */ (function () {
    function DetailsPagePageModule() {
    }
    DetailsPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_details_page_page__WEBPACK_IMPORTED_MODULE_6__["DetailsPagePage"]]
        })
    ], DetailsPagePageModule);
    return DetailsPagePageModule;
}());



/***/ }),

/***/ "./src/app/product/details-page/details-page.page.html":
/*!*************************************************************!*\
  !*** ./src/app/product/details-page/details-page.page.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>detailsPage</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/product/details-page/details-page.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/product/details-page/details-page.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QvZGV0YWlscy1wYWdlL2RldGFpbHMtcGFnZS5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/product/details-page/details-page.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/product/details-page/details-page.page.ts ***!
  \***********************************************************/
/*! exports provided: DetailsPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPagePage", function() { return DetailsPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var DetailsPagePage = /** @class */ (function () {
    function DetailsPagePage() {
    }
    DetailsPagePage.prototype.ngOnInit = function () {
    };
    DetailsPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-details-page',
            template: __webpack_require__(/*! ./details-page.page.html */ "./src/app/product/details-page/details-page.page.html"),
            styles: [__webpack_require__(/*! ./details-page.page.scss */ "./src/app/product/details-page/details-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], DetailsPagePage);
    return DetailsPagePage;
}());



/***/ }),

/***/ "./src/app/product/edit-page/edit-page.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/product/edit-page/edit-page.module.ts ***!
  \*******************************************************/
/*! exports provided: EditPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPagePageModule", function() { return EditPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _edit_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-page.page */ "./src/app/product/edit-page/edit-page.page.ts");







var routes = [
    {
        path: '',
        component: _edit_page_page__WEBPACK_IMPORTED_MODULE_6__["EditPagePage"]
    }
];
var EditPagePageModule = /** @class */ (function () {
    function EditPagePageModule() {
    }
    EditPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_edit_page_page__WEBPACK_IMPORTED_MODULE_6__["EditPagePage"]]
        })
    ], EditPagePageModule);
    return EditPagePageModule;
}());



/***/ }),

/***/ "./src/app/product/edit-page/edit-page.page.html":
/*!*******************************************************!*\
  !*** ./src/app/product/edit-page/edit-page.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>editPage</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/product/edit-page/edit-page.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/product/edit-page/edit-page.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QvZWRpdC1wYWdlL2VkaXQtcGFnZS5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/product/edit-page/edit-page.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/product/edit-page/edit-page.page.ts ***!
  \*****************************************************/
/*! exports provided: EditPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPagePage", function() { return EditPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var EditPagePage = /** @class */ (function () {
    function EditPagePage() {
    }
    EditPagePage.prototype.ngOnInit = function () {
    };
    EditPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-edit-page',
            template: __webpack_require__(/*! ./edit-page.page.html */ "./src/app/product/edit-page/edit-page.page.html"),
            styles: [__webpack_require__(/*! ./edit-page.page.scss */ "./src/app/product/edit-page/edit-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], EditPagePage);
    return EditPagePage;
}());



/***/ }),

/***/ "./src/app/product/home-page/home-page.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/product/home-page/home-page.module.ts ***!
  \*******************************************************/
/*! exports provided: HomePagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePagePageModule", function() { return HomePagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/scrolling */ "./node_modules/@angular/cdk/esm5/scrolling.es5.js");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "./node_modules/@angular/cdk/esm5/drag-drop.es5.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _home_page_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./home-page.page */ "./src/app/product/home-page/home-page.page.ts");









var routes = [
    {
        path: '',
        component: _home_page_page__WEBPACK_IMPORTED_MODULE_8__["HomePagePage"]
    }
];
var HomePagePageModule = /** @class */ (function () {
    function HomePagePageModule() {
    }
    HomePagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["IonicModule"],
                _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_5__["ScrollingModule"],
                _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_6__["DragDropModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_home_page_page__WEBPACK_IMPORTED_MODULE_8__["HomePagePage"]]
        })
    ], HomePagePageModule);
    return HomePagePageModule;
}());



/***/ }),

/***/ "./src/app/product/home-page/home-page.page.html":
/*!*******************************************************!*\
  !*** ./src/app/product/home-page/home-page.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>HomePage</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content> -->\n\n\n<ion-header>\n  <ion-toolbar>\n    <ion-title>Home</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <cdk-virtual-scroll-viewport cdkDropList itemSize=\"20\" class=\"example-viewport\" (cdkDropListDropped)=\"drop($event)\">\n    <ion-item *cdkVirtualFor=\"let p of products\" class=\"example-item\" href=\"/tabs/(details:{{p._id}})\" cdkDrag>\n      <ion-icon name=\"desktop\" slot=\"start\"></ion-icon>\n      {{p.prod_name}}\n      <div class=\"item-note\" slot=\"end\">\n        {{p.prod_price | currency}}\n      </div>\n    </ion-item>\n  </cdk-virtual-scroll-viewport>\n</ion-content>"

/***/ }),

/***/ "./src/app/product/home-page/home-page.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/product/home-page/home-page.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QvaG9tZS1wYWdlL2hvbWUtcGFnZS5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/product/home-page/home-page.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/product/home-page/home-page.page.ts ***!
  \*****************************************************/
/*! exports provided: HomePagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePagePage", function() { return HomePagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _product_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../product-service.service */ "./src/app/product/product-service.service.ts");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "./node_modules/@angular/cdk/esm5/drag-drop.es5.js");






var HomePagePage = /** @class */ (function () {
    function HomePagePage(api, loadingController, router, route) {
        this.api = api;
        this.loadingController = loadingController;
        this.router = router;
        this.route = route;
        this.products = [];
    }
    HomePagePage.prototype.ngOnInit = function () {
        this.getProducts();
    };
    HomePagePage.prototype.getProducts = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var loading;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.loadingController.create({
                            message: 'Loading...'
                        })];
                    case 1:
                        loading = _a.sent();
                        return [4 /*yield*/, loading.present()];
                    case 2:
                        _a.sent();
                        return [4 /*yield*/, this.api.getProducts()
                                .subscribe(function (res) {
                                _this.products = res;
                                console.log(_this.products);
                                loading.dismiss();
                            }, function (err) {
                                console.log(err);
                                loading.dismiss();
                            })];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    HomePagePage.prototype.drop = function (event) {
        Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_5__["moveItemInArray"])(this.products, event.previousIndex, event.currentIndex);
    };
    HomePagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home-page',
            template: __webpack_require__(/*! ./home-page.page.html */ "./src/app/product/home-page/home-page.page.html"),
            styles: [__webpack_require__(/*! ./home-page.page.scss */ "./src/app/product/home-page/home-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_product_service_service__WEBPACK_IMPORTED_MODULE_4__["ProductServiceService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
            _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], HomePagePage);
    return HomePagePage;
}());



/***/ }),

/***/ "./src/app/product/product-service.service.ts":
/*!****************************************************!*\
  !*** ./src/app/product/product-service.service.ts ***!
  \****************************************************/
/*! exports provided: ProductServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductServiceService", function() { return ProductServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _product__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./product */ "./src/app/product/product.ts");






var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var apiUrl = "/api/v1/products";
var ProductServiceService = /** @class */ (function () {
    function ProductServiceService(http) {
        this.http = http;
        this.products = [];
    }
    ProductServiceService.prototype.getProducts = function () {
        var _this = this;
        // const url = `${apiUrl}`;
        // return this.http.get<Product[]>(url).pipe(
        //   tap(_ => console.log(`fetched all product`)),
        //   catchError(this.handleError<Product[]>(`getProducts`))
        // );
        this.products.push(new _product__WEBPACK_IMPORTED_MODULE_5__["Product"](1, "Laptop", "", 100, new Date()));
        this.products.push(new _product__WEBPACK_IMPORTED_MODULE_5__["Product"](2, "Desktop", "", 100, new Date()));
        this.products.push(new _product__WEBPACK_IMPORTED_MODULE_5__["Product"](3, "Mouse", "", 10, new Date()));
        this.products.push(new _product__WEBPACK_IMPORTED_MODULE_5__["Product"](4, "Keybord", "", 10, new Date()));
        return new rxjs__WEBPACK_IMPORTED_MODULE_2__["Observable"](function (obs) { return obs.next(_this.products); });
    };
    ProductServiceService.prototype.getProduct = function (id) {
        var url = apiUrl + "/" + id;
        return this.http.get(url).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (_) { return console.log("fetched product id=" + id); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError("getProduct id=" + id)));
    };
    ProductServiceService.prototype.addProduct = function (product) {
        return this.http.post(apiUrl, product, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (product) { return console.log("added product w/ id=" + product.id); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('addProduct')));
    };
    ProductServiceService.prototype.updateProduct = function (id, product) {
        var url = apiUrl + "/" + id;
        return this.http.put(url, product, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (_) { return console.log("updated product id=" + id); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('updateProduct')));
    };
    ProductServiceService.prototype.deleteProduct = function (id) {
        var url = apiUrl + "/" + id;
        return this.http.delete(url, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (_) { return console.log("deleted product id=" + id); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(this.handleError('deleteProduct')));
    };
    ProductServiceService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // Let the app keep running by returning an empty result.
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(result);
        };
    };
    ProductServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], ProductServiceService);
    return ProductServiceService;
}());



/***/ }),

/***/ "./src/app/product/product.ts":
/*!************************************!*\
  !*** ./src/app/product/product.ts ***!
  \************************************/
/*! exports provided: Product */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Product", function() { return Product; });
var Product = /** @class */ (function () {
    function Product(id, prod_name, prod_desc, prod_price, updated_at) {
    }
    return Product;
}());



/***/ }),

/***/ "./src/app/product/tabs-page/tabs-page.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/product/tabs-page/tabs-page.module.ts ***!
  \*******************************************************/
/*! exports provided: TabsPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPagePageModule", function() { return TabsPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tabs_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tabs-page.page */ "./src/app/product/tabs-page/tabs-page.page.ts");







var routes = [
    {
        path: '',
        component: _tabs_page_page__WEBPACK_IMPORTED_MODULE_6__["TabsPagePage"]
    }
];
var TabsPagePageModule = /** @class */ (function () {
    function TabsPagePageModule() {
    }
    TabsPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tabs_page_page__WEBPACK_IMPORTED_MODULE_6__["TabsPagePage"]]
        })
    ], TabsPagePageModule);
    return TabsPagePageModule;
}());



/***/ }),

/***/ "./src/app/product/tabs-page/tabs-page.page.html":
/*!*******************************************************!*\
  !*** ./src/app/product/tabs-page/tabs-page.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>TabsPage</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content> -->\n\n\n<ion-tabs>\n\n  <ion-tab tab=\"home\">\n    <ion-router-outlet name=\"home\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab tab=\"details\">\n    <ion-router-outlet name=\"details\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab tab=\"add\">\n    <ion-router-outlet name=\"add\"></ion-router-outlet>\n  </ion-tab>\n  <ion-tab tab=\"edit\">\n    <ion-router-outlet name=\"edit\"></ion-router-outlet>\n  </ion-tab>\n\n  <ion-tab-bar slot=\"bottom\">\n\n    <ion-tab-button tab=\"home\" href=\"/tabs/(home:home)\">\n      <ion-icon name=\"home\"></ion-icon>\n      <ion-label>Home</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"details\" href=\"/tabs/(details:null)\">\n      <ion-icon name=\"eye\"></ion-icon>\n      <ion-label>Details</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"add\" href=\"/tabs/(add:add)\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Add</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"edit\" href=\"/tabs/(edit:null)\">\n      <ion-icon name=\"create\"></ion-icon>\n      <ion-label>Edit</ion-label>\n    </ion-tab-button>\n\n  </ion-tab-bar>\n\n</ion-tabs>"

/***/ }),

/***/ "./src/app/product/tabs-page/tabs-page.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/product/tabs-page/tabs-page.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Byb2R1Y3QvdGFicy1wYWdlL3RhYnMtcGFnZS5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/product/tabs-page/tabs-page.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/product/tabs-page/tabs-page.page.ts ***!
  \*****************************************************/
/*! exports provided: TabsPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPagePage", function() { return TabsPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var TabsPagePage = /** @class */ (function () {
    function TabsPagePage() {
    }
    TabsPagePage.prototype.ngOnInit = function () {
    };
    TabsPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tabs-page',
            template: __webpack_require__(/*! ./tabs-page.page.html */ "./src/app/product/tabs-page/tabs-page.page.html"),
            styles: [__webpack_require__(/*! ./tabs-page.page.scss */ "./src/app/product/tabs-page/tabs-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], TabsPagePage);
    return TabsPagePage;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\SachinK\Applications\MobileApp\Horizon\Horizon\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map